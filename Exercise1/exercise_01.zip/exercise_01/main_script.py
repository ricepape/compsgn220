# This is a script to perform the execution of the functions provided 
# in exercise no. 1 and also the ones implemented by the student. Please, place
# the execution of each task as separated by the template below. The whole code should 
# run automatically, provided the correct directories. 
# The TA will not debug your code.



#### TASK 2.1
#### Place the execution of task 2.1 below



#### TASK 2.2
#### Place the execution of task 2.2 below



#### TASK 3.1
#### Place the execution of task 3.1 below



#### TASK 3.2
#### Place the execution of task 3.2 below



#### TASK 4.1
#### Place the execution of task 4.1 below



#### TASK 4.2
#### Place the execution of task 4.2 below

